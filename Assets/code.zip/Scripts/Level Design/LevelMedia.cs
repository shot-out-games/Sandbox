﻿using UnityEngine;

[System.Serializable]

public class LevelMedia
{

    // Use this for initialization
    public AudioClip levelMusic = null;




}


