﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovesManager : MonoBehaviour
{
    public List<Moves> Moves = new List<Moves>();

 
   
}
