﻿using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;



//[UpdateInGroup(typeof(FixedStepSimulationSystemGroup))]
public class CustomSystemGroup : ComponentSystemGroup
{
    

}
