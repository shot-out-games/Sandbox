﻿using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;
using UnityEngine.AI;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Transforms;
using System.Collections;



public enum WayPointAction
{
    Move,
    Jump
}


[System.Serializable]
public class WayPoint
{
    public Vector3 targetPosition;
    public Vector3 offset;
    public WayPointAction action;

}


public struct EnemyStateComponent : IComponentData
{
    public MoveStates MoveState;
    public CombatStates CombatState;

}

public enum MoveStates
{
    Default,
    Idle,
    Patrol,
    Chase
};

public enum CombatStates
{
    Default,
    Idle,
    Chase,
    Stance,
    Aim
};

public enum EnemyRoles
{
    Chase,
    Patrol,
    Evade,
    Random
};

public enum NavigationStates
{
    Default,
    Movement,
    Melee,
    Weapon
};



public enum AttackStages
{
    No,
    Start,
    Action,
    End
}


public struct MeleeComponent : IComponentData
{
    public bool Available;
    public float hitPower;
    public float gameHitPower;
    public bool anyTouchDamage;
}
public struct EnemyAttackComponent : IComponentData
{
    public AttackStages AttackStage;

}




public class EnemyMove : MonoBehaviour, IConvertGameObjectToEntity
{
    [HideInInspector]
    public NavMeshAgent agent;
    private Animator anim;

    public float chaseRange;
    public float combatRangeDistance;
    public float shootRangeDistance;

    //[HideInInspector]
    public List<WayPoint> wayPoints = new List<WayPoint>();
    [SerializeField]
    private int currentWayPointIndex = 0;
    [SerializeField]
    private WayPoint currentWayPoint;
    [SerializeField]
    private bool isCurrentWayPointJump;

    public bool randomWayPoints = false;
    public EnemyRoles enemyRole;
    public float moveSpeed;
    public float rotateSpeed = 1;
    [SerializeField] private float speed;
    [SerializeField] private Vector3 lastPosition;

    public Transform target;//default chase target but if combat used gets replaced by combatsystem move target
    public Entity entity;
    private EntityManager manager;
    private EnemyRatings enemyRatings;

    public float speedMultiple;
    public bool backup;

    [SerializeField]
    private Vector3 originalPosition;
    private Vector3 destinationBeforeRewind;
    private bool currentRewind;

    [SerializeField] private bool manualRootMotion = true;

    public AudioSource audioSource;
    public AudioClip clip;
    public ParticleSystem ps;

    public ParticleSystem stunEffect;




    //[SerializeField]
    //Vector3[] offsets;
    [SerializeField]
    Vector3 leapTarget;
    [SerializeField]
    float duration = 3.0f;
    float normalizedTime = 0.0f;
    Vector3 startPos;
    Vector3 endPos;

    [SerializeField] private float remDistance;

    public AnimationCurve curve = new AnimationCurve();


    void Init()
    {
        enemyRatings = GetComponent<EnemyRatings>();
        chaseRange = 18;
        combatRangeDistance = 6;
        shootRangeDistance = 8;

        agent = GetComponent<NavMeshAgent>();
        moveSpeed = 3.5f;

        RatingsComponent ratings = manager.GetComponentData<RatingsComponent>(entity);
        if (enemyRatings)
        {
            chaseRange = ratings.chaseRangeDistance;
            combatRangeDistance = ratings.combatRangeDistance;
            shootRangeDistance = ratings.shootRangeDistance;
            agent.speed = ratings.speed;
            moveSpeed = agent.speed;

        }



        agent.autoBraking = false;
        anim = GetComponent<Animator>();
        agent.updateRotation = false;
        agent.autoTraverseOffMeshLink = false;

        //agent.updatePosition = false;

        originalPosition = transform.position;


    }


    void Start()
    {

        SetWaypoints(randomWayPoints);

    }

    public void SetWaypoints(bool _randomWayPoints)
    {
        for (int i = 0; i < wayPoints.Count; i++)
        {
            WayPoint wayPoint = wayPoints[i];
            wayPoint.targetPosition = transform.position + wayPoint.offset;
            wayPoint.action = wayPoints[i].action;
            wayPoints[i] = wayPoint;
        }

    }

    public void Patrol()
    {

        if (wayPoints.Count == 0 | agent.enabled == false)
            return;

        float distance = isCurrentWayPointJump ? .0003f : .5f;

        remDistance = agent.remainingDistance;

        if (agent.pathPending == false && agent.remainingDistance < distance)
        {
            anim.SetInteger("JumpState", 0);
            agent.destination = wayPoints[currentWayPointIndex].targetPosition;
            isCurrentWayPointJump = wayPoints[currentWayPointIndex].action == WayPointAction.Jump;

            if (isCurrentWayPointJump)
            {
                //StartCoroutine(Curve(agent, duration));
                //Debug.Log("wp jump");
                anim.SetInteger("JumpState", 1);
                normalizedTime = 0.0f;
                startPos = agent.transform.position;
                endPos = wayPoints[currentWayPointIndex].targetPosition + Vector3.up * agent.baseOffset;
            }


            currentWayPointIndex = (currentWayPointIndex + 1) % wayPoints.Count;


        }

        //Debug.Log("ad patrol " + agent.destination);


        if (isCurrentWayPointJump == false)
        {
            AnimationMovement();
        }

    }



    void Curve()
    {
        //agent.updatePosition = false;

        if (normalizedTime < 1.0f)
        {

            float yOffset = curve.Evaluate(normalizedTime);
            agent.transform.position = Vector3.Lerp(startPos, endPos, normalizedTime) + yOffset * Vector3.up;
            normalizedTime += Time.deltaTime / duration;
        }
        else
        {
            isCurrentWayPointJump = false;
            anim.SetInteger("JumpState", 0);

        }

    }



    void OnDrawGizmos()
    {
        if (agent == null) return;
        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(agent.destination, .095f);
    }



    public void FaceWaypoint()
    {
        if (!agent.enabled) return;
        Vector3 lookDir = agent.destination - transform.position;
        lookDir.y = 0;
        if (lookDir.magnitude < .019f) return;
        Quaternion rot = Quaternion.LookRotation(lookDir);
        transform.rotation = Quaternion.Slerp(transform.rotation, rot, rotateSpeed * Time.deltaTime);

    }






    public void FacePlayer()
    {
        if (!agent.enabled) return;
        Vector3 lookDir = target.position - transform.position;
        lookDir.y = 0;
        if (lookDir.magnitude < .019f) return;
        Quaternion rot = Quaternion.LookRotation(lookDir);
        transform.rotation = Quaternion.Slerp(transform.rotation, rot, rotateSpeed * Time.deltaTime);

    }


    public void SetBackup()
    {
        if (agent == null || manager == null || entity == Entity.Null) return;

        if (agent.enabled)
        {
            //agent.updatePosition = false;
            //agent.ResetPath();
            Vector3 nextPosition = target.position;
            Vector3 offset = transform.forward * Time.deltaTime * moveSpeed * 2;


            agent.Move(-offset);
            AnimationMovement();
        }
    }

    public void SetDestination()
    {
        if (agent == null || manager == null || entity == Entity.Null) return;

        bool noX = false;
        bool noZ = true;
        noZ = false;

        if (agent.enabled)
        {
            Vector3 nextPosition = target.position;
            if (noZ) nextPosition.z = 0;
            agent.destination = nextPosition;
            AnimationMovement();
        }
    }






    public void AnimationMovement()
    {

        if (target == null || anim == null) return;


        if (backup == false)
        {
            agent.updatePosition = true;
        }


        MoveStates state = manager.GetComponentData<EnemyStateComponent>(entity).MoveState;
        int pursuitMode = anim.GetInteger("Zone");
        agent.speed = pursuitMode >= 2 ? moveSpeed : moveSpeed * 2;
        Vector3 forward =
            transform.InverseTransformDirection(transform.forward); //world to local so always local forward (0,0,1)


        float velx = 0;
        float velz = forward.normalized.z;

        if (currentRewind == true)
        {
            agent.speed = moveSpeed * 2;
            velz = velz * 2;
        }
        else if (state == MoveStates.Idle)
        {
            agent.speed = 0;
            velz = 0;
        }
        else if (state == MoveStates.Patrol)
        {
            agent.speed = moveSpeed * .5f;
            velz = .5f;
        }

        velz = velz * speedMultiple;

        //if (math.abs(agent.velocity.magnitude) < .000001f) velz = 0;

        speed = Mathf.Lerp(speed, (transform.position - lastPosition).magnitude / Time.deltaTime, .19f);
        //bool lastSpeed = speed > .000001f;
        //speed = (transform.position - lastPosition).magnitude;
        if (math.abs(speed) <= .000001f) velz = 0;
        lastPosition = transform.position;

        //Debug.Log("sp " + speed);
        //anim.SetFloat("velx", velx);
        anim.SetFloat("velz", velz);

    }


    void OnAnimatorMove()
    {

        if (agent == null || manager == null || entity == Entity.Null) return;
        if (isCurrentWayPointJump == false)
        {
            agent.updatePosition = true;
            float speed = speedMultiple * 1.0f;
            Vector3 velocity = anim.deltaPosition / Time.deltaTime * speed;

            //Vector3 forward =
               // transform.InverseTransformDirection(Vector3.forward); //world to local so always local forward (0,0,1)

            transform.position = agent.nextPosition;

            //transform.position = new Vector3(transform.position.x, transform.position.y, 0);//2d

        }
        else if (isCurrentWayPointJump)
        {
            //Debug.Log("curve");
            Curve();
        }



    }


    public void Convert(Entity _entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
    {
        entity = _entity;
        dstManager.AddComponentData(entity, new EnemyStateComponent { MoveState = MoveStates.Default, CombatState = CombatStates.Default });
        manager = dstManager;
        Init();
    }


}


