﻿using RootMotion.FinalIK;
using SandBox.Player;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Jobs;
using Unity.Mathematics;
using Unity.Physics;
using Unity.Physics.Systems;
using Unity.Transforms;
using UnityEngine;
using SphereCollider = Unity.Physics.SphereCollider;




[UpdateAfter(typeof(Unity.Physics.Systems.EndFramePhysicsSystem))]
[UpdateInGroup(typeof(FixedStepSimulationSystemGroup))]



public class PickupRaycastSystem : SystemBase
{


    public enum CollisionLayer
    {
        Player = 1 << 0,
        Ground = 1 << 1,
        Enemy = 1 << 2,
        Item = 1 << 3
    }


    protected override void OnUpdate()
    {
        bool pickedUp = false;
        Entity pickedUpEntity = Entity.Null;
        InteractionObject interactionObject = null;
        Entity pickerUpper = Entity.Null;


        var bufferFromEntity = GetBufferFromEntity<WeaponItemComponent>();



        //        Entities.WithoutBurst().WithStructuralChanges().ForEach((Entity entity, WeaponItem WeaponItem, ref WeaponItemComponent weaponItemComponent,
        //         ref Translation translation, ref PhysicsCollider collider, ref Rotation rotation) =>
        Entities.WithoutBurst().WithStructuralChanges().ForEach((Entity entity, WeaponItem WeaponItem,
                ref Translation translation, ref PhysicsCollider collider, ref Rotation rotation) =>
        {

            if (bufferFromEntity.HasComponent(entity))
            {
                //var bufferFromEntity = GetBufferFromEntity<WeaponItemComponent>();
                var weaponItemComponent = bufferFromEntity[entity];


                var physicsWorldSystem = World.GetExistingSystem<Unity.Physics.Systems.BuildPhysicsWorld>();
                var collisionWorld = physicsWorldSystem.PhysicsWorld.CollisionWorld;


                float3 start = translation.Value + new float3(0f, .38f, 0);
                float3 direction = new float3(0, 0, 0);
                float distance = 2f;
                float3 end = start + direction * distance;


                PointDistanceInput pointDistanceInput = new PointDistanceInput
                {
                    Position = start,
                    MaxDistance = distance,
                    //Filter = CollisionFilter.Default
                    Filter = new CollisionFilter()
                    {
                        //BelongsTo = (uint)CollisionLayer.Player,
                        //CollidesWith = (uint)CollisionLayer.Item,
                        BelongsTo = 4u,
                        CollidesWith = 1u,
                        GroupIndex = 0
                    }
                };

                Debug.DrawRay(start, Vector3.right, Color.green, distance * 10f);





                bool hasPointHit = collisionWorld.CalculateDistance(pointDistanceInput, out DistanceHit pointHit);
                if (HasComponent<TriggerComponent>(pointHit.Entity))
                {
                    var parent = EntityManager.GetComponentData<TriggerComponent>(pointHit.Entity).ParentEntity;
                    pickerUpper = parent;
                    Debug.Log(" pt e " + pickerUpper);

                }


                if (hasPointHit && weaponItemComponent[0].pickedUp == false)
                {


                    Entity e = physicsWorldSystem.PhysicsWorld.Bodies[pointHit.RigidBodyIndex].Entity;
                    //Debug.Log("ve " + applyImpulse.Velocity.x);
                    //Debug.Log("left / right");
                    if (WeaponItem.e == entity)
                    {
                        //weaponItemComponent.pickedUp = true;

                        var intBufferElement = weaponItemComponent[0];
                        intBufferElement.pickedUp = true;
                        weaponItemComponent[0] = intBufferElement;

                        pickedUp = true;
                        pickedUpEntity = entity;
                        interactionObject = WeaponItem.interactionObject;
                        //Debug.Log(" pt e " + e);
                    }
                }


                start = translation.Value + new float3(0, .03f, 0);
                direction = new float3(0, -1, 0);
                distance = .35f;
                end = start + direction * distance;



            }




        }).Run();


        if (pickedUp)
        {



            Entities.WithoutBurst().ForEach((WeaponInteraction weaponInteraction, WeaponManager weaponManager, Entity e) =>
            {
                if (pickerUpper == e)
                {
                    weaponManager.DetachPrimaryWeapon(); //need to add way to set to not picked up  afterwards
                    weaponInteraction.interactionObject = interactionObject;
                    //weaponManager.primaryWeapon.weaponGameObject = interactionObject.gameObject;
                    weaponManager.primaryWeapon.weaponGameObject =
                        interactionObject.GetComponent<WeaponItem>().gameObject; //always the same as go for now
                    weaponManager.AttachPrimaryWeapon();
                    weaponInteraction.UpdateSystem();
                    Debug.Log("MATCH FOUND");
                }
                else
                {
                    pickedUp = false;
                    var weaponItemBufferList = GetBufferFromEntity<WeaponItemComponent>();
                    var weaponItemComponent = bufferFromEntity[pickedUpEntity];
                    var intBufferElement = weaponItemComponent[0];
                    intBufferElement.pickedUp = false;
                    weaponItemComponent[0] = intBufferElement;

                }

            }).Run();

            //EntityManager.DestroyEntity(pickedUpEntity);

        }

        if (pickedUp == true)
        {
            EntityManager.SetComponentData(pickedUpEntity, new Translation { Value = new float3(0, -2500, 0) });
        }
        else
        {

        }


    }




}


