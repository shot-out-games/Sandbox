﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveData
{
    public  List<SaveGames> saveGames = new List<SaveGames>();

}
