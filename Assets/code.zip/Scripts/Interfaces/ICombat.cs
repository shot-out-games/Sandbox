﻿using UnityEngine;

public interface ICombat
{
    AttackStages AttackStage { get; set; }
    //float damageLanded { get; set; }
    //float damageReceived { get; set; }
}


