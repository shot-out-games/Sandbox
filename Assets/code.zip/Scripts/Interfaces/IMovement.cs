﻿using UnityEngine;

public interface IMovement
{
    //    void CalculateStrikeDistanceFromPinPosition(Transform aimTransform);

    //float speedMultiple { get; set; }

}


